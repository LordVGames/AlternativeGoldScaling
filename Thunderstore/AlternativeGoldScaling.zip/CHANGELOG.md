## 1.0.2

- Fixed SS2 beta check causing problems

## 1.0.1

- Adjusted default values
- - I've played many runs since installing this and have tweaked some config values over time. I think I've found the sweetspot for the values so some of the defaults have been changed to what I've got.
- - All config values can still be fully configured to whatever you like/need.

## 1.0.0

- First release